The ffmpeg.exe binary was compiled using https://github.com/rdp/ffmpeg-windows-build-helpers with the following command line options
```
./cross_compile_ffmpeg.sh --ffmpeg-git-checkout-version=n3.2.1 
```

